namespace InventoryManagementSystem.Api.DTOs.Requests;

public class CreateCategoryRequest { }
